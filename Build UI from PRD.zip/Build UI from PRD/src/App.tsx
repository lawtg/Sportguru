import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react"

type IconName = "arrow" | "book" | "check" | "chevron" | "clock" | "close" | "copy" | "database" | "menu" | "search" | "shield" | "spark" | "trend" | "users"

function Icon({ name, size = 18 }: { name: IconName size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    book: (
      <>
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    close: (
      <>
        <path d="m6 6 12 12" />
        <path d="M18 6 6 18" />
      </>
    ),
    copy: (
      <>
        <rect width="13" height="13" x="8" y="8" rx="2" />
        <path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3" />
      </>
    ),
    database: (
      <>
        <ellipse cx="12" cy="5" rx="8" ry="3" />
        <path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5" />
        <path d="M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7" />
      </>
    ),
    menu: (
      <>
        <path d="M4 7h16" />
        <path d="M4 12h16" />
        <path d="M4 17h16" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    shield: (
      <>
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
        <path d="m9 12 2 2 4-4" />
      </>
    ),
    spark: (
      <>
        <path d="m12 3-1.4 4.1L6.5 8.5l4.1 1.4L12 14l1.4-4.1 4.1-1.4-4.1-1.4L12 3Z" />
        <path d="m5 14-.8 2.2L2 17l2.2.8L5 20l.8-2.2L8 17l-2.2-.8L5 14Z" />
      </>
    ),
    trend: (
      <>
        <path d="m3 17 6-6 4 4 8-8" />
        <path d="M15 7h6v6" />
      </>
    ),
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
  }
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

const suggestions = [
  {
    type: "Player",
    title: "Cristiano Ronaldo",
    meta: "Forward · Portugal",
    mark: "CR",
    tone: "blue",
  },
  {
    type: "Player",
    title: "Lionel Messi",
    meta: "Forward · Argentina",
    mark: "LM",
    tone: "sky",
  },
  {
    type: "Club",
    title: "Real Madrid",
    meta: "Spain · Founded 1902",
    mark: "RM",
    tone: "gold",
  },
  {
    type: "Debate",
    title: "Who has more career goals?",
    meta: "Ronaldo vs Messi · Verified",
    mark: "VS",
    tone: "green",
  },
]

const popular = [
  "Ronaldo vs Messi",
  "Real Madrid trophies",
  "Premier League winners",
  "All-time top scorers",
]

const knowledge = [
  {
    type: "Player profile",
    title: "Kylian Mbappé",
    meta: "France · Forward",
    mark: "KM",
    tone: "navy",
    updated: "Updated 2h ago",
  },
  {
    type: "Club profile",
    title: "Manchester City",
    meta: "England · Founded 1880",
    mark: "MC",
    tone: "sky",
    updated: "Updated yesterday",
  },
  {
    type: "Competition",
    title: "UEFA Champions League",
    meta: "Europe · Club competition",
    mark: "CL",
    tone: "blue",
    updated: "Verified 3 days ago",
  },
]

function Logo() {
  return (
    <button
      className="brand"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="Sport Guru home"
    >
      <span className="brand-mark">
        <span>SG</span>
      </span>
      <span className="brand-name">
        SPORT<span>GURU</span>
      </span>
    </button>
  )
}

function AppButton({
  children,
  className = "",
  onClick,
  type = "button",
}: {
  children: ReactNode
  className?: string
  onClick?: () => void
  type?: "button" | "submit"
}) {
  return (
    <button type={type} className={className} onClick={onClick}>
      {children}
    </button>
  )
}

function SearchBox({
  large = false,
  onSubmit,
}: {
  large?: boolean
  onSubmit: (query: string) => void
}) {
  const [query, setQuery] = useState("")
  const [focused, setFocused] = useState(false)
  const filtered = useMemo(() => {
    if (!query.trim()) return suggestions.slice(0, 3)
    return suggestions.filter((item) =>
      `${item.title} ${item.type} ${item.meta}`
        .toLowerCase()
        .includes(query.toLowerCase()),
    )
  }, [query])

  const submit = (event: FormEvent) => {
    event.preventDefault()
    if (query.trim()) {
      onSubmit(query)
      setFocused(false)
    }
  }

  return (
    <div className={`search-wrap ${large ? "search-large" : ""}`}>
      <form className="search-form" onSubmit={submit}>
        <Icon name="search" size={large ? 22 : 18} />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          onFocus={() => setFocused(true)}
          placeholder="Search players, clubs, records, or ask a question..."
          aria-label="Search football knowledge"
        />
        {query && (
          <AppButton className="clear-search" onClick={() => setQuery("")}>
            <Icon name="close" size={16} />
          </AppButton>
        )}
        <AppButton type="submit" className="search-action">
          {large ? "Search knowledge" : "Search"}
        </AppButton>
      </form>
      {focused && (
        <div className="search-popover">
          <div className="popover-label">
            {query ? "Best matches" : "Popular right now"}
          </div>
          {filtered.length ? (
            filtered.map((item) => (
              <button
                key={item.title}
                className="suggestion"
                onMouseDown={() => {
                  setQuery(item.title)
                  onSubmit(item.title)
                  setFocused(false)
                }}
              >
                <span className={`entity-mark ${item.tone}`}>{item.mark}</span>
                <span>
                  <strong>{item.title}</strong>
                  <small>
                    {item.type} · {item.meta}
                  </small>
                </span>
                <Icon name="chevron" size={16} />
              </button>
            ))
          ) : (
            <div className="empty-search">
              <Icon name="search" />
              <span>No exact match. Try a player, club, or competition.</span>
            </div>
          )}
          <div className="popover-foot">
            <span>Press Enter to search everything</span>
            <kbd>↵</kbd>
          </div>
        </div>
      )}
    </div>
  )
}

function SectionHeading({
  eyebrow,
  title,
  description,
  link,
}: {
  eyebrow: string
  title: string
  description?: string
  link?: string
}) {
  return (
    <div className="section-heading">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {link && (
        <button className="text-link">
          {link}
          <Icon name="arrow" />
        </button>
      )}
    </div>
  )
}

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [resultsQuery, setResultsQuery] = useState("")
  const [copied, setCopied] = useState(false)
  const [scope, setScope] = useState<"career" | "club">("career")

  useEffect(() => {
    if (!copied) return
    const timer = window.setTimeout(() => setCopied(false), 1800)
    return () => window.clearTimeout(timer)
  }, [copied])

  const runSearch = (query: string) => {
    setResultsQuery(query)
    window.setTimeout(
      () =>
        document
          .getElementById("search-results")
          ?.scrollIntoView({ behavior: "smooth", block: "start" }),
      30,
    )
  }

  const navTo = (id: string) => {
    setMobileOpen(false)
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="header-inner">
          <Logo />
          <nav
            className={`main-nav ${mobileOpen ? "open" : ""}`}
            aria-label="Main navigation"
          >
            <button onClick={() => navTo("top")}>Home</button>
            <button onClick={() => navTo("recent")}>Players</button>
            <button onClick={() => navTo("recent")}>Clubs</button>
            <button onClick={() => navTo("recent")}>Competitions</button>
            <button onClick={() => navTo("compare")}>Comparisons</button>
          </nav>
          <div className="header-actions">
            <AppButton className="header-search" onClick={() => navTo("top")}>
              <Icon name="search" />
              <span>Search</span>
            </AppButton>
            <AppButton
              className="menu-button"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              <Icon name={mobileOpen ? "close" : "menu"} />
            </AppButton>
          </div>
        </div>
      </header>

      <main>
        <section className="hero" id="top">
          <div className="hero-grid">
            <div className="hero-copy">
              <div className="hero-kicker">
                <Icon name="shield" size={16} /> Verified football knowledge
              </div>
              <h1>
                Know the game.
                <br />
                <em>Prove your point.</em>
              </h1>
              <p className="hero-lede">
                Find reliable facts, compare the greats, and settle football
                debates with evidence you can trust.
              </p>
              <SearchBox large onSubmit={runSearch} />
              <div className="popular-searches">
                <span>Popular:</span>
                {popular.slice(0, 3).map((item) => (
                  <button key={item} onClick={() => runSearch(item)}>
                    {item}
                  </button>
                ))}
              </div>
              <div className="trust-row">
                <div>
                  <strong>12,400+</strong>
                  <span>Verified facts</span>
                </div>
                <i />
                <div>
                  <strong>2,800+</strong>
                  <span>Source records</span>
                </div>
                <i />
                <div>
                  <strong>100%</strong>
                  <span>Evidence-led</span>
                </div>
              </div>
            </div>
            <div className="hero-visual" aria-label="Football stadium at night">
              <div className="photo-credit">Photo by Izuddin Helmi Adnan</div>
              <div className="live-card">
                <div className="live-card-top">
                  <span className="verified-pill">
                    <Icon name="check" size={12} /> VERIFIED ANSWER
                  </span>
                  <span>All competitions</span>
                </div>
                <p>Who has scored the most official goals in men’s football?</p>
                <div className="answer-row">
                  <span className="entity-mark blue">CR</span>
                  <div>
                    <strong>Cristiano Ronaldo</strong>
                    <small>Portugal · Forward</small>
                  </div>
                  <b>900+</b>
                </div>
                <div className="source-line">
                  <Icon name="database" size={14} /> Cross-checked against 4
                  trusted sources
                </div>
              </div>
              <div className="hero-index">
                THE WORLD’S GAME
                <br />
                <b>01</b>
              </div>
            </div>
          </div>
        </section>

        {resultsQuery && (
          <section className="search-results-section" id="search-results">
            <div className="content-wrap">
              <div className="results-top">
                <div>
                  <span className="eyebrow">Search results</span>
                  <h2>Results for “{resultsQuery}”</h2>
                </div>
                <AppButton
                  className="close-results"
                  onClick={() => setResultsQuery("")}
                >
                  <Icon name="close" /> Close
                </AppButton>
              </div>
              <div className="results-grid">
                {suggestions.slice(0, 3).map((item, index) => (
                  <button className="result-card" key={item.title}>
                    <span className={`entity-mark ${item.tone}`}>
                      {item.mark}
                    </span>
                    <span className="result-info">
                      <small>{item.type}</small>
                      <strong>
                        {index === 0 && resultsQuery
                          ? resultsQuery
                          : item.title}
                      </strong>
                      <span>{item.meta}</span>
                    </span>
                    <Icon name="arrow" />
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        <section className="popular-section">
          <div className="content-wrap">
            <SectionHeading
              eyebrow="Trending knowledge"
              title="What fans are searching"
              description="Popular questions, profiles, and records across the football world."
              link="Explore all knowledge"
            />
            <div className="topic-grid">
              <button
                className="topic-card topic-feature"
                onClick={() => navTo("compare")}
              >
                <div className="topic-number">01</div>
                <div className="versus-avatars">
                  <span className="player-avatar ronaldo">CR</span>
                  <span className="vs-dot">VS</span>
                  <span className="player-avatar messi">LM</span>
                </div>
                <span className="card-tag">Most searched comparison</span>
                <h3>Ronaldo vs Messi</h3>
                <p>Compare goals, assists, honours, and career records.</p>
                <span className="card-link">
                  Compare players <Icon name="arrow" />
                </span>
              </button>
              <button className="topic-card">
                <div className="topic-number">02</div>
                <span className="entity-mark xlarge gold">RM</span>
                <span className="card-tag">Club profile</span>
                <h3>Real Madrid</h3>
                <p>
                  Explore the club’s history, honours, records, and iconic
                  players.
                </p>
                <span className="card-link">
                  View club profile <Icon name="arrow" />
                </span>
              </button>
              <button className="topic-card">
                <div className="topic-number">03</div>
                <span className="entity-mark xlarge navy">PL</span>
                <span className="card-tag">Competition history</span>
                <h3>Premier League</h3>
                <p>Every champion, record holder, and defining season.</p>
                <span className="card-link">
                  Explore competition <Icon name="arrow" />
                </span>
              </button>
              <button className="topic-card quick-list">
                <div className="topic-number">04</div>
                <span className="card-tag">Popular questions</span>
                <h3>Settle a debate</h3>
                {[
                  "Who has the most Ballon d’Or wins?",
                  "Which club has won the most UCL titles?",
                  "Who is the Premier League’s top scorer?",
                ].map((q) => (
                  <span className="quick-question" key={q}>
                    {q}
                    <Icon name="chevron" size={15} />
                  </span>
                ))}
              </button>
            </div>
          </div>
        </section>

        <section className="comparison-section" id="compare">
          <div className="content-wrap comparison-wrap">
            <div className="comparison-intro">
              <span className="eyebrow light">Featured comparison</span>
              <h2>
                Greatness looks
                <br />
                different in the data.
              </h2>
              <p>
                Compare careers side by side using a consistent scope,
                transparent definitions, and traceable sources.
              </p>
              <div
                className="scope-toggle"
                role="group"
                aria-label="Comparison scope"
              >
                <button
                  className={scope === "career" ? "active" : ""}
                  onClick={() => setScope("career")}
                >
                  Career
                </button>
                <button
                  className={scope === "club" ? "active" : ""}
                  onClick={() => setScope("club")}
                >
                  Club only
                </button>
              </div>
              <div className="method-note">
                <Icon name="shield" />
                <span>
                  <strong>Fair by design</strong>We never declare a subjective
                  “winner.” You see the measurable differences.
                </span>
              </div>
            </div>
            <div className="comparison-card">
              <div className="compare-head">
                <div>
                  <span className="player-avatar ronaldo">CR</span>
                  <strong>C. Ronaldo</strong>
                  <small>Portugal</small>
                </div>
                <span>HEAD TO HEAD</span>
                <div>
                  <span className="player-avatar messi">LM</span>
                  <strong>L. Messi</strong>
                  <small>Argentina</small>
                </div>
              </div>
              <div className="metric">
                <span className="winning">
                  {scope === "career" ? "900+" : "450"}
                </span>
                <label>Official goals</label>
                <span>{scope === "career" ? "850+" : "672"}</span>
                <i className="bar left" />
                <i className="bar right goals" />
              </div>
              <div className="metric">
                <span>{scope === "career" ? "250+" : "131"}</span>
                <label>Assists</label>
                <span className="winning">
                  {scope === "career" ? "380+" : "269"}
                </span>
                <i className="bar left assists-left" />
                <i className="bar right" />
              </div>
              <div className="metric">
                <span className="winning">5</span>
                <label>Champions League</label>
                <span>4</span>
                <i className="bar left" />
                <i className="bar right trophy" />
              </div>
              <div className="metric">
                <span>5</span>
                <label>Ballon d’Or</label>
                <span className="winning">8</span>
                <i className="bar left award-left" />
                <i className="bar right" />
              </div>
              <div className="compare-footer">
                <span>
                  <Icon name="clock" size={14} /> Last verified 18 Jun 2025
                </span>
                <button onClick={() => setCopied(true)}>
                  <Icon name={copied ? "check" : "copy"} size={16} />
                  {copied ? "Link copied" : "Share comparison"}
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="recent-section" id="recent">
          <div className="content-wrap">
            <SectionHeading
              eyebrow="Fresh from the archive"
              title="Recently added"
              description="New and newly verified pages from our growing knowledge base."
              link="View all updates"
            />
            <div className="knowledge-grid">
              {knowledge.map((item) => (
                <button className="knowledge-card" key={item.title}>
                  <span className={`entity-mark poster ${item.tone}`}>
                    {item.mark}
                    <i />
                  </span>
                  <span className="knowledge-body">
                    <small>{item.type}</small>
                    <strong>{item.title}</strong>
                    <span>{item.meta}</span>
                    <em>
                      <Icon name="check" size={12} /> {item.updated}
                    </em>
                  </span>
                  <span className="round-arrow">
                    <Icon name="arrow" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className="how-section">
          <div className="content-wrap">
            <div className="how-header">
              <div>
                <span className="eyebrow">Built for the truth</span>
                <h2>
                  From question to
                  <br />
                  credible answer.
                </h2>
              </div>
              <p>
                Football knowledge shouldn’t be scattered, unclear, or
                impossible to verify. Sport Guru makes the facts easy to find,
                understand, and share.
              </p>
            </div>
            <div className="steps">
              {[
                {
                  n: "01",
                  icon: "search" as IconName,
                  title: "Find the question",
                  text: "Search any player, club, competition, record, or football debate.",
                },
                {
                  n: "02",
                  icon: "database" as IconName,
                  title: "Review the evidence",
                  text: "See structured statistics, clear scope, and the sources behind every claim.",
                },
                {
                  n: "03",
                  icon: "trend" as IconName,
                  title: "Compare with context",
                  text: "Explore measurable differences without misleading or universal verdicts.",
                },
                {
                  n: "04",
                  icon: "copy" as IconName,
                  title: "Share with confidence",
                  text: "Send one stable, evidence-backed link and settle the discussion.",
                },
              ].map((step) => (
                <div className="step" key={step.n}>
                  <span className="step-count">{step.n}</span>
                  <span className="step-icon">
                    <Icon name={step.icon} />
                  </span>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="cta-section">
          <div className="cta-inner">
            <span className="cta-ball">
              <Icon name="spark" size={28} />
            </span>
            <h2>
              Your next football answer
              <br />
              starts here.
            </h2>
            <p>
              Search thousands of facts, records, profiles, and comparisons.
            </p>
            <AppButton className="cta-button" onClick={() => navTo("top")}>
              Search football knowledge <Icon name="arrow" />
            </AppButton>
          </div>
        </section>
      </main>

      <footer>
        <div className="footer-main">
          <div className="footer-brand">
            <Logo />
            <p>
              The trusted knowledge and credibility platform for football fans
              worldwide.
            </p>
          </div>
          <div className="footer-links">
            <strong>Explore</strong>
            <button onClick={() => navTo("recent")}>Players</button>
            <button onClick={() => navTo("recent")}>Clubs</button>
            <button onClick={() => navTo("recent")}>Competitions</button>
            <button onClick={() => navTo("compare")}>Comparisons</button>
          </div>
          <div className="footer-links">
            <strong>Sport Guru</strong>
            <button>About us</button>
            <button>Our methodology</button>
            <button>Data sources</button>
            <button>Contact</button>
          </div>
          <div className="footer-links">
            <strong>Stay informed</strong>
            <p>Get new records and stories from football history.</p>
            <div className="email-box">
              <input aria-label="Email address" placeholder="Email address" />
              <button aria-label="Subscribe">
                <Icon name="arrow" />
              </button>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2025 Sport Guru. Independent football knowledge.</span>
          <div>
            <button>Privacy</button>
            <button>Terms</button>
            <button>Report an error</button>
          </div>
        </div>
      </footer>
    </div>
  )
}
